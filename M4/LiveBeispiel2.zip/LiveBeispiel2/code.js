
function addElement () {
    let input = document.getElementById("addInput");
    let list = document.getElementById("weblist");

    let li = document.createElement("li");
    // node.innerText = input.value;

    let btn = document.createElement("button");
    btn.setAttribute("class", "btn btn-danger d-none");
    btn.setAttribute("type", "button");
    btn.innerHTML = "&times;"

    

    
    li.appendChild(btn);
    li.innerHTML += "<span>" + input.value + "</span>"; 
    
    valueList.push (input.value);
    
    input.value = "";
    
    list.appendChild(li);

    // btn.addEventListener("click", deleteElement);
    let array = document.getElementsByClassName('btn-danger');
    array[array.length-1].onclick = deleteElement;
}

function toggleVisibility() {
    let btnArray = document.getElementsByClassName('btn-danger');
    for (let i = 0; i < btnArray.length; i++){
        let elem = btnArray[i];
        elem.classList.toggle('d-none');
    }
    document.getElementById("weblist").classList.toggle('none-list-style');
}

function deleteElement (e) {
    e.target.parentNode.parentNode.removeChild(e.target.parentNode);
    //todo valueList säubern
}

document.getElementById('editBtn').addEventListener("click", toggleVisibility);

let deleteBtnArray = document.getElementsByClassName('btn-danger');
for (let i = 0; i < deleteBtnArray.length; i++){
    let elem = deleteBtnArray[i];
    // elem.onclick = deleteElement;
    elem.addEventListener("click", deleteElement);
}

function save () {
    localStorage.setItem('list', valueList);
}


let valueList = ['HTML', 'CSS', 'JavaScript', 'VSC'];